<?php
session_start();

$logged_in = isset($_SESSION['user_email']);

// Logout functionality
if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: index.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ecommerce Website</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />
</head>
    
    <section id="header">
        <a href="#"><img src="img/logo.png" class="logo" alt=""></a>

        <div>
            <ul id="navbar">
                <li><a class="active" href="index.php">Home</a></li>
                <li><a href="shop.php">Shop</a></li>
                <li><a href="blog.php">Blog</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="contact.php">Contact</a></li>
                <li class="lg-bag"><a href="cart.php"><i class="far fa-shopping-bag"></i></a></li>
                <?php if ($logged_in): ?>
                    <li><a href="#">Welcome, <?php echo htmlspecialchars($_SESSION['user_name']); ?></a></li>
                    <li><a href="index.php?logout=1">Logout</a></li>
                <?php else: ?>
                    <li><a href="login.php">Login</a></li>
                <?php endif; ?>
            </ul>
        </div>
        <div id="mobile">
            <a href="cart.html"><i class="far fa-shopping-bag"></i></a>
            <i id="bar" class="fas fa-outdent"></i>
        </div>
    </section>

    <section id="hero">
        <h4>Trade-in offer</h4>
        <h2>Super Value Deals</h2>
        <h1>On All Products</h1>
        <p>Save more with coupon & up to 50% off</p>
        <button>Shop Now</button>
    </section>

    <section id="feature" class="section-p1">
        <div class="fe-box">
            <img src="img/features/f1.png" alt="">
            <h6>Free Shipping</h6>
        </div>
        <div class="fe-box">
            <img src="img/features/f2.png" alt="">
            <h6>Online Order</h6>
        </div>
        <div class="fe-box">
            <img src="img/features/f3.png" alt="">
            <h6>12.12 Deal</h6>
        </div>
        <div class="fe-box">
            <img src="img/features/f4.png" alt="">
            <h6>Promotion</h6>
        </div>
        <div class="fe-box">
            <img src="img/features/f5.png" alt="">
            <h6>Happy Hour</h6>
        </div>
        <div class="fe-box">
            <img src="img/features/f6.png" alt="">
            <h6>Support</h6>
        </div>
    </section>

   
    
    <section id="product1" class="section-p1">
        <h2>Featured Products</h2>
        <p>Summer Collection New Modern Design</p>
   
        <div class="pro-container">
             <?php include('server/get_featured_products.php');
             while($row= $featured_products->fetch_assoc()) { ?>
                <div class="pro">
                <img src="<?php echo $row['image'];?>" alt="">
                <div class="des">
                    <span>thisisneverthat</span>
                    <h5><?php echo $row['name']; ?></h5>
                    <div class="star">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <h4><?php echo $row['price'];?></h4>
                </div>
                <a href="<?php echo "sproduct.php?id=". $row['id']; ?>"><i class="fal fa-shopping-cart"></i></a>
            </div>

            <?php } ?>
    </section>

    <section id="banner" class="section-m1">
        <h4>Repair Services</h4>
        <h2>Up to <span>50% Off</span> - All T-Shirt & Accessories</h2>
        <button class="normal">Explore More</button>
    </section>

    <section id="product1" class="section-p1">
        <h2>New Arrivals</h2>
        <p>Autumn Collection Series</p>
        <div class="pro-container">
            <div class="pro">
                <img src="img/products/f18.jpg" alt="">
                <div class="des">
                    <span>thisisneverthat</span>
                    <h5>Classic Hoodie</h5>
                    <div class="star">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <h4>RM150.00</h4>
                </div>
                <a href="#"><i class="fal fa-shopping-cart"></i></a>
            </div>
            <div class="pro">
                <img src="img/products/f1.jpg" alt="">
                <div class="des">
                    <span>Carhatt</span>
                    <h5>Classic Hoodie</h5>
                    <div class="star">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <h4>RM300.00</h4>
                </div>
                <a href="#"><i class="fal fa-shopping-cart"></i></a>
            </div>
            <div class="pro">
                <img src="img/products/f2.jpg" alt="">
                <div class="des">
                    <span>Carhatt</span>
                    <h5>Small Logo Crewneck</h5>
                    <div class="star">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <h4>RM78.00</h4>
                </div>
                <a href="#"><i class="fal fa-shopping-cart"></i></a>
            </div>            
        </div>
    </section>

    <section id="sm-banner" class="section-p1">
        <div class="banner-box">
            <h4>Summer Deals</h4>
            <h2>50% For The Second Item</h2>
            <span>The best apparel is on sale now.</span>
            <button class="white">Learn More</button>
        </div>
        <div class="banner-box banner-box2">
            <h4>Summer / Winter</h4>
            <h2>Upcoming Season</h2>
            <span>The best apparel is on sale now.</span>
            <button class="white">Collection</button>
        </div>
    </section>

    <section id="banner3">
        <div class="banner-box">
            <h2>Seasonal Sales</h2>
            <h3>Winter Collection - 40% Off</h3>
        </div>
        <div class="banner-box banner-box2">
            <h2>Footwear</h2>
            <h3>Summer 22'</h3>
        </div>
        <div class="banner-box banner-box3">
            <h2>Carhatt Collection</h2>
            <h3>Jacket, Shirts, Pants</h3>
        </div>
    </section>

    <section id="newsletter" class="section-p1 section-m1">
        <div class="newstext">
            <h4>Sign Up for Newsletter</h4>
            <p>Get e-Mail updates about our latest drop and <span>special offers</span></p>
        </div>
        <div class="form">
            <input type="text" id="email" placeholder="Your e-Mail Address">
            <button class="normal" id="notify-button">Notify Me</button>
            <div id="notification" class="notification" style="display: none;">
                Thank you for subscribing! We will notify you soon.
            </div>
        </div>
    </section>

    <footer class="section-p1">
        <div class="col">
            <img  class="logo" src="img/logo.png" alt="">
            <h4>Contact</h4>
            <p>Address<strong>14, Gotham Street, 24 South Bridge</strong></p>
            <p>Phone<strong>  (+60)3-3457-6789</strong></p>
            <p>Operation Hours <strong>0800 - 2200, Mon - Sat</strong></p>
            <div class="follow">
                <h4>Follow Us</h4>
                <div class="icon">
                    <i class="fab fa-facebook-f"></i>
                    <i class="fab fa-twitter"></i>
                    <i class="fab fa-instagram"></i>
                    <i class="fab fa-pinterest"></i>
                    <i class="fab fa-youtube"></i>
                </div>
            </div>
        </div>

        <div class="col">
            <h4>About</h4>
            <a href="#">About Us</a>
            <a href="#">Delivery Information</a>
            <a href="#">Privacy & Policy</a>
            <a href="#">Terms & Conditions</a>
            <a href="#">Contact Us</a>
        </div>

        <div class="col">
            <h4>My Account</h4>
            <a href="#">Sign In</a>
            <a href="#">View Cart</a>
            <a href="#">Wishlist</a>
            <a href="#">Track My Order</a>
        </div>

        <div class="col install">
            <h4>Install App</h4>
            <p>App Store or Google Play</p>
            <div class="row">
                <img src="img/pay/app.jpg" alt="">
                <img src="img/pay/play.jpg" alt="">
                <p>Secured Payment Gateways</p>
                <img src="img/pay/pay.png" alt="">
            </div>
        </div>

        <div class="copyright">
            <p>2024, Cara Enterprise</p>
        </div>
    </footer>

    <script src="script.js"></script>
</body>
</html>