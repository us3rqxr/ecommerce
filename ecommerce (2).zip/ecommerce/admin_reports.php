<?php
session_start();
require_once 'server/db.php';

// Check if the user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

// Function to get total sales
function getTotalSales($conn) {
    $stmt = $conn->prepare("SELECT SUM(total_amount) AS total_sales FROM orders WHERE order_status = 'delivered'");
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    return $result['total_sales'] ?? 0;
}

// Function to get top-selling products
function getTopSellingProducts($conn, $limit = 5) {
    $stmt = $conn->prepare("SELECT p.id, p.name, SUM(oi.quantity) AS total_sold
                            FROM products p
                            JOIN order_items oi ON p.id = oi.product_id
                            JOIN orders o ON oi.order_id = o.order_id
                            WHERE o.order_status = 'delivered'
                            GROUP BY p.id
                            ORDER BY total_sold DESC
                            LIMIT ?");
    $stmt->bind_param("i", $limit);
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

// Function to get recent orders
function getRecentOrders($conn, $limit = 10) {
    $stmt = $conn->prepare("SELECT o.order_id, u.user_name, o.total_amount, o.order_status, o.created_at
                            FROM orders o
                            JOIN users u ON o.user_id = u.user_id
                            ORDER BY o.created_at DESC
                            LIMIT ?");
    $stmt->bind_param("i", $limit);
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

$totalSales = getTotalSales($conn);
$topSellingProducts = getTopSellingProducts($conn);
$recentOrders = getRecentOrders($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports - Admin Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 0;
        }
        .navbar {
            background-color: #333;
            color: white;
            padding: 1rem;
        }
        .navbar ul {
            list-style-type: none;
            padding: 0;
            margin: 0;
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
        }
        .navbar li a {
            color: white;
            text-decoration: none;
            padding: 0.5rem 1rem;
        }
        .navbar li a:hover {
            background-color: #555;
        }
        .content {
            padding: 20px;
            max-width: 1200px;
            margin: 0 auto;
        }
        h1, h2 {
            color: #333;
        }
        .report-section {
            background-color: #f9f9f9;
            border-radius: 5px;
            padding: 20px;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f2f2f2;
        }
        @media (max-width: 768px) {
            .navbar ul {
                flex-direction: column;
            }
            .navbar li {
                margin-bottom: 10px;
            }
            table {
                font-size: 14px;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <ul>
            <li><a href="admin_dashboard.php">Dashboard</a></li>
            <li><a href="admin_users.php">Users</a></li>
            <li><a href="admin_products.php">Products</a></li>
            <li><a href="admin_orders.php">Orders</a></li>
            <li><a href="admin_reports.php">Reports</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </nav>
    <div class="content">
        <h1>Reports</h1>
        
        <div class="report-section">
            <h2>Total Sales</h2>
            <p>Total sales for delivered orders: $<?php echo number_format($totalSales, 2); ?></p>
        </div>

        <div class="report-section">
            <h2>Top Selling Products</h2>
            <table>
                <thead>
                    <tr>
                        <th>Product ID</th>
                        <th>Product Name</th>
                        <th>Total Sold</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($topSellingProducts as $product): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($product['id']); ?></td>
                        <td><?php echo htmlspecialchars($product['name']); ?></td>
                        <td><?php echo htmlspecialchars($product['total_sold']); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <div class="report-section">
            <h2>Recent Orders</h2>
            <table>
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>User</th>
                        <th>Total Amount</th>
                        <th>Status</th>
                        <th>Created At</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($recentOrders as $order): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($order['order_id']); ?></td>
                        <td><?php echo htmlspecialchars($order['user_name']); ?></td>
                        <td>$<?php echo number_format($order['total_amount'], 2); ?></td>
                        <td><?php echo htmlspecialchars($order['order_status']); ?></td>
                        <td><?php echo htmlspecialchars($order['created_at']); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
