<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ecommerce Website</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />
</head>
<body>
    <section id="header">
        <a href="#"><img src="img/logo.png" class="logo" alt=""></a>
        <div>
            <ul id="navbar">
                <li><a href="index.php">Home</a></li>
                <li><a href="shop.php">Shop</a></li>
                <li><a href="blog.php">Blog</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="contact.php">Contact</a></li>
                <li class="lg-bag"><a href="cart.php"><i class="far fa-shopping-bag"></i></a></li>
                <li class="lg-bag"><a href="login.php">Login</i></a></li>
            </ul>
        </div>
        <div id="mobile">
            <a href="cart.html"><i class="far fa-shopping-bag"></i></a>
            <i id="bar" class="fas fa-outdent"></i>
        </div>
    </section>

    <section id="page-header" class="about-header">
        <h2>Your Cart</h2>
        <p>Review and Complete Your Purchase</p>
    </section>
    <section id="cart" class="section-p1">
    <table width="100%">
        <thead>
            <tr>
                <td>Remove</td>
                <td>Image</td>
                <td>Products</td>
                <td>Price</td>
                <td>Quantity</td>
                <td>Subtotal</td>
            </tr>
        </thead>
        <tbody>
<?php
$total = 0; // Initialize the total
if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $product_id => $item) {
        $subtotal = $item['price'] * $item['quantity'];
        $total += $subtotal; // Add subtotal to the total
        ?>
        <tr>
            <td><a href="remove_from_cart.php?id=<?php echo $product_id; ?>">Remove</a></td>
            <td><img src="<?php echo $item['image']; ?>" alt="<?php echo $item['name']; ?>" style="width: 50px;"></td>
            <td><?php echo $item['name']; ?></td>
            <td>RM<?php echo number_format($item['price'], 2); ?></td>
            <td><?php echo $item['quantity']; ?></td>
            <td>RM<?php echo number_format($subtotal, 2); ?></td>
        </tr>
        <?php
    }
    ?>
    <tr>
        <td colspan="5"><strong>Total:</strong></td>
        <td><strong>RM<?php echo number_format($total, 2); ?></strong></td>
    </tr>
    <?php
} else {
    echo "<tr><td colspan='6'>Your cart is empty.</td></tr>";
}
?>
</tbody>
</table>
<div id="grand-total-container">
    <h3 id="total">Total: RM<?php echo number_format($total, 2); ?></h3>
</div>
    <div class="checkout-btn">
        <a href="checkout.php" class="button">Checkout</a>
    </div>
</section>


    <footer class="section-p1">
        <div class="col">
            <img  class="logo" src="img/logo.png" alt="">
            <h4>Contact</h4>
            <p>Address <strong>here</strong></p>
            <p>Phone <strong>(+60)17-891-0111</strong></p>
            <p>Operation Hours <strong>0800 - 2200, Mon - Fri</strong></p>
            <div class="follow">
                <h4>Follow Us</h4>
                <div class="icon">
                    <i class="fab fa-facebook-f"></i>
                    <i class="fab fa-twitter"></i>
                    <i class="fab fa-instagram"></i>
                    <i class="fab fa-pinterest"></i>
                    <i class="fab fa-youtube"></i>
                </div>
            </div>
        </div>

        <div class="col">
            <h4>About</h4>
            <a href="#">About Us</a>
            <a href="#">Delivery Information</a>
            <a href="#">Privacy & Policy</a>
            <a href="#">Terms & Conditions</a>
            <a href="#">Contact Us</a>
        </div>

        <div class="col">
            <h4>My Account</h4>
            <a href="#">Sign In</a>
            <a href="#">View Cart</a>
            <a href="#">Wishlist</a>
            <a href="#">Track My Order</a>
        </div>

        <div class="col install">
            <h4>Install App</h4>
            <p>App Store or Google Play</p>
            <div class="row">
                <img src="img/pay/app.jpg" alt="">
                <img src="img/pay/play.jpg" alt="">
                <p>Secured Payment Gateways</p>
                <img src="img/pay/pay.png" alt="">
            </div>
        </div>

        <div class="copyright">
            <p>2024, Atmos Enterprise</p>
        </div>
    </footer>
</body>
</html>