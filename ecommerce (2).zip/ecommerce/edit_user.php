<?php
session_start();
require_once 'server/db.php';

// Check if the user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

$user_id = $_GET['id'] ?? null;

if (!$user_id) {
    header("Location: admin_dashboard.php");
    exit();
}

$error = '';
$success = '';

// Fetch user data
$stmt = $conn->prepare("SELECT user_id, user_name, user_email, user_role FROM users WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user) {
    header("Location: admin_dashboard.php");
    exit();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $role = $_POST['role'] ?? '';

    if (empty($name) || empty($email) || empty($role)) {
        $error = "All fields are required.";
    } else {
        $stmt = $conn->prepare("UPDATE users SET user_name = ?, user_email = ?, user_role = ? WHERE user_id = ?");
        $stmt->bind_param("sssi", $name, $email, $role, $user_id);
        
        if ($stmt->execute()) {
            $success = "User updated successfully.";
            // Refresh user data
            $user['user_name'] = $name;
            $user['user_email'] = $email;
            $user['user_role'] = $role;
        } else {
            $error = "Error updating user: " . $conn->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 20px;
        }
        h1 {
            color: #333;
        }
        form {
            max-width: 400px;
            margin-top: 20px;
        }
        label {
            display: block;
            margin-top: 10px;
        }
        input[type="text"],
        input[type="email"],
        select {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
        }
        input[type="submit"] {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 10px 15px;
            margin-top: 10px;
            cursor: pointer;
        }
        .error {
            color: red;
        }
        .success {
            color: green;
        }
    </style>
</head>
<body>
    <h1>Edit User</h1>
    
    <?php if ($error): ?>
        <p class="error"><?php echo $error; ?></p>
    <?php endif; ?>
    
    <?php if ($success): ?>
        <p class="success"><?php echo $success; ?></p>
    <?php endif; ?>

    <form method="POST">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($user['user_name']); ?>" required>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($user['user_email']); ?>" required>

        <label for="role">Role:</label>
        <select id="role" name="role" required>
            <option value="user" <?php echo $user['user_role'] === 'user' ? 'selected' : ''; ?>>User</option>
            <option value="admin" <?php echo $user['user_role'] === 'admin' ? 'selected' : ''; ?>>Admin</option>
        </select>

        <input type="submit" value="Update User">
    </form>

    <a href="admin_dashboard.php">Back to Dashboard</a>
</body>
</html>
        