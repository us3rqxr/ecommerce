<?php
// Include your database connection
require_once 'server/db.php';

// Check if the connection is successful
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// User credentials
$email = 'faiz@gmail.com';
$password = 'faiz123';

// Hash the password
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Prepare and execute the update statement
$stmt = $conn->prepare("UPDATE users SET user_password = ? WHERE user_email = ?");
$stmt->bind_param("ss", $hashed_password, $email);

if ($stmt->execute()) {
    echo "Password updated successfully for $email";
} else {
    echo "Error updating password: " . $stmt->error;
}

// Close the statement and connection
$stmt->close();
$conn->close();
?>
 