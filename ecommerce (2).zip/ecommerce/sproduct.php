<?php
session_start();
include('server/db.php');

if (isset($_GET['id'])) {
    $product_id = $_GET['id'];
    $stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $product = $stmt->get_result()->fetch_assoc();

    if (!$product) {
        header('Location: index.php');
        exit;
    }
} else {
    header('Location: index.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ecommerce Website</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />
<body>
    
    <section id="header">
        <a href="#"><img src="img/logo.png" class="logo" alt=""></a>

        <div>
        <ul id="navbar">
            <li><a href="index.php">Home</a></li>
            <li><a class="active" href="shop.php">Shop</a></li>
            <li><a href="blog.php">Blog</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li class="lg-bag"><a href="cart.php"><i class="far fa-shopping-bag"></i></a></li>
            <li class="lg-bag"><a href="login.php"><i class="far fa-solid fa-user"></i></a></li>
            <a href="#" id="close"> <i class="far fa-times"></i></a>
    </div>
    <div id="mobile">
        <a href="cart.html"><i class="far fa-shopping-bag"></i></a>
        <i id="bar" class="fas fa-outdent"></i>
    </div>
</section>

    <section id="prodetails" class="section-p1">
        <div class="single-pro-image">
            <img src="<?php echo $product['image']; ?>" width="100%" id="MainImg" alt="">
        </div>
        <div class="single-pro-details">
            <h6><?php echo $product['category']; ?></h6>
            <h4><?php echo $product['name']; ?></h4>
            <h2>RM<?php echo $product['price']; ?></h2>
            <form method="POST" action="cart.php">
                <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                <select name="size">
                    <option>Select Size</option>
                    <option>XL</option>
                    <option>XXL</option>
                    <option>Small</option>
                    <option>Large</option>
                </select>
                <input type="number" name="quantity" value="1">
                <button type="submit" name="add_to_cart" class="normal">Add To Cart</button>
            </form>
            <h4>Product Details</h4>
            <span><?php echo $product['description']; ?></span>
        </div>
    </section>


    <section id="product1" class="section-p1">
        <h2>Featured Products</h2>
        <p>Autumn Collection Series</p>
        <div class="pro-container">
            <div class="pro">
                <img src="img/products/f12.jpg" alt="">
                <div class="des">
                    <span>thisisneverthat</span>
                    <h5>Classic Crew T-shirt</h5>
                    <div class="star">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <h4>RM78.00</h4>
                </div>
                <a href="#"><i class="fal fa-shopping-cart"></i></a>
            </div>
            <div class="pro">
                <img src="img/products/f10.jpg" alt="">
                <div class="des">
                    <span>Keen</span>
                    <h5>Hiking Sandal</h5>
                    <div class="star">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <h4>RM78.00</h4>
                </div>
                <a href="#"><i class="fal fa-shopping-cart"></i></a>
            </div>
            <div class="pro">
                <img src="img/products/f14.jpg" alt="">
                <div class="des">
                    <span>thisisneverthat</span>
                    <h5>Long Sleeve T-shirt</h5>
                    <div class="star">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <h4>RM78.00</h4>
                </div>
                <a href="#"><i class="fal fa-shopping-cart"></i></a>
            </div>
            <div class="pro">
                <img src="img/products/f11.jpg" alt="">
                <div class="des">
                    <span>Keen</span>
                    <h5>Jasper Sandal</h5>
                    <div class="star">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <h4>RM78.00</h4>
                </div>
                <a href="#"><i class="fal fa-shopping-cart"></i></a>
            </div>
            <div class="pro">
                <img src="img/products/f13.jpg" alt="">
                <div class="des">
                    <span>thisisneverthat</span>
                    <h5>Green Logo Hoodie</h5>
                    <div class="star">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <h4>RM78.00</h4>
                </div>
                <a href="#"><i class="fal fa-shopping-cart"></i></a>
            </div>
            <div class="pro">
                <img src="img/products/f9.jpg" alt="">
                <div class="des">
                    <span>Carhatt</span>
                    <h5>Overall Woman</h5>
                    <div class="star">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <h4>RM78.00</h4>
                </div>
                <a href="#"><i class="fal fa-shopping-cart"></i></a>
            </div>
    </section>

    <section id="newsletter" class="section-p1 section-m1">
        <div class="newstext">
            <h4>Sign Up for Newsletter</h4>
            <p>Get e-Mail updates about our latest drop and <span>special offers</span></p>
        </div>
        <div class="form">
            <input type="text" placeholder="Your e-Mail Address">
            <button class="normal">Notify Me</button>
        </div>
    </section>

    <footer class="section-p1">
        <div class="col">
            <img  class="logo" src="img/logo.png" alt="">
            <h4>Contact</h4>
            <p>Address <strong>here</strong></p>
            <p>Phone <strong>(+60)17-891-0111</strong></p>
            <p>Operation Hours <strong>0800 - 2200, Mon - Fri</strong></p>
            <div class="follow">
                <h4>Follow Us</h4>
                <div class="icon">
                    <i class="fab fa-facebook-f"></i>
                    <i class="fab fa-twitter"></i>
                    <i class="fab fa-instagram"></i>
                    <i class="fab fa-pinterest"></i>
                    <i class="fab fa-youtube"></i>
                </div>
            </div>
        </div>

        <div class="col">
            <h4>About</h4>
            <a href="#">About Us</a>
            <a href="#">Delivery Information</a>
            <a href="#">Privacy & Policy</a>
            <a href="#">Terms & Conditions</a>
            <a href="#">Contact Us</a>
        </div>

        <div class="col">
            <h4>My Account</h4>
            <a href="#">Sign In</a>
            <a href="#">View Cart</a>
            <a href="#">Wishlist</a>
            <a href="#">Track My Order</a>
        </div>

        <div class="col install">
            <h4>Install App</h4>
            <p>App Store or Google Play</p>
            <div class="row">
                <img src="img/pay/app.jpg" alt="">
                <img src="img/pay/play.jpg" alt="">
                <p>Secured Payment Gateways</p>
                <img src="img/pay/pay.png" alt="">
            </div>
        </div>

        <div class="copyright">
            <p>2024, Cara Enterprise</p>
        </div>
    </footer>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const addToCartButton = document.getElementById('add-to-cart');
    
            addToCartButton.addEventListener('click', () => {
                // Define the product details
                const product = {
                    id: addToCartButton.dataset.id,
                    name: addToCartButton.dataset.name,
                    price: addToCartButton.dataset.price,
                    image: addToCartButton.dataset.image,
                    quantity: document.querySelector('input[type="number"]').value
                };
    
                // Get the current cart from Local Storage or create a new array
                const cart = JSON.parse(localStorage.getItem('cart')) || [];
    
                // Check if the item is already in the cart
                const existingItemIndex = cart.findIndex(item => item.id === product.id);
                if (existingItemIndex !== -1) {
                    // Update the quantity if it already exists
                    cart[existingItemIndex].quantity = parseInt(cart[existingItemIndex].quantity) + parseInt(product.quantity);
                } else {
                    // Add the new item
                    cart.push(product);
                }
    
                // Save back to Local Storage
                localStorage.setItem('cart', JSON.stringify(cart));
    
                alert('Item added to cart!');
            });
        });
    </script>
    
    
    <script src="script.js"></script>
</body>
</html>