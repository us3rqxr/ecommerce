<?php
session_start();

// Check if cart exists in session
if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    echo "Your cart is empty.";
    exit;
}

// Collect billing information
$fullName = $_POST['fullName'];
$email = $_POST['email'];
// Additional address and payment info

// Calculate total
$total = 0;
foreach ($_SESSION['cart'] as $item) {
    $total += $item['price'] * $item['quantity'];
}

// Add tax (example: 5%)
$tax = 0.05 * $total;
$finalTotal = $total + $tax;

// Generate order ID
$orderId = "ORD-" . rand(100000, 999999);

// Store receipt information in session
$_SESSION['receipt'] = [
    'orderId' => $orderId,
    'fullName' => $fullName,
    'email' => $email,
    'items' => $_SESSION['cart'],
    'total' => $total,
    'tax' => $tax,
    'finalTotal' => $finalTotal
];

// Clear the cart after purchase
unset($_SESSION['cart']);

// Redirect to the receipt page
header('Location: receipt.php');
exit;
