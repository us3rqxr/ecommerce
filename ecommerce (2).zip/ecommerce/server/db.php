<?php
$host = 'localhost';
$user = 'root'; // Default MySQL user for XAMPP
$password = ''; // Leave blank for XAMPP default
$database = 'ecommerce';

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

return $conn;
?>
