<?php

include('db.php');

$stmt = $conn->prepare("SELECT * FROM products LIMIT 12");

$stmt->execute();

$products = $stmt->get_result();

?>