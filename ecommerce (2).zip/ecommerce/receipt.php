<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

// Check if the receipt data exists in the session
if (!isset($_SESSION['receipt'])) {
    echo "Receipt not found. Please make sure you have completed the order process.";
    exit;
}

// Access the receipt data
$receipt = $_SESSION['receipt'];

// Debug: Print the receipt data
// echo "<pre>Debug: "; print_r($receipt); echo "</pre>";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receipt</title>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; padding: 20px; }
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
    </style>
</head>
<body>
    <h1>Order Receipt</h1>
    <p><strong>Order ID:</strong> <?php echo $receipt['orderId']; ?></p>
    <p><strong>Name:</strong> <?php echo $receipt['fullName']; ?></p>
    <p><strong>Email:</strong> <?php echo $receipt['email']; ?></p>
    <p><strong>Address:</strong> <?php echo $receipt['address']; ?>, <?php echo $receipt['city']; ?>, <?php echo $receipt['state']; ?> <?php echo $receipt['zip']; ?></p>

    <h2>Order Details</h2>
    <table>
        <thead>
            <tr>
                <th>Product</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>Subtotal</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($receipt['items'] as $item): ?>
            <tr>
                <td><?php echo $item['name']; ?></td>
                <td>RM<?php echo number_format($item['price'], 2); ?></td>
                <td><?php echo $item['quantity']; ?></td>
                <td>RM<?php echo number_format($item['price'] * $item['quantity'], 2); ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <p><strong>Tax:</strong> RM<?php echo number_format($receipt['tax'], 2); ?></p>
    <p><strong>Total:</strong> RM<?php echo number_format($receipt['total'], 2); ?></p>

    <p>Thank you for your purchase!</p>
</body>
</html>
