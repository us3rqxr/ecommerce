<?php
// Include your database connection file
require_once 'server/db.php';

// Check if the connection is successful
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// The email of the user whose password hash you want to check
$email = 'faiz@gmail.com'; // Replace this with the actual email you're checking

// Prepare and execute the query
$stmt = $conn->prepare("SELECT user_email, user_password FROM users WHERE user_email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
    echo "Email: " . htmlspecialchars($user['user_email']) . "<br>";
    echo "Stored Password Hash: " . htmlspecialchars($user['user_password']);
} else {
    echo "No user found with email: " . htmlspecialchars($email);
}

// Close the statement and connection
$stmt->close();
$conn->close();
?>
