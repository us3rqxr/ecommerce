<?php
session_start();

// Debugging: Check if session data exists
// var_dump($_SESSION); // This will print the session contents to debug if necessary

// Check if the cart is empty
if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    echo "Your cart is empty.";
    exit;
}

// Process form data when submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $fullName = $_POST['fullName'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    $city = $_POST['city'];
    $state = $_POST['state'];
    $zip = $_POST['zip'];

    // Calculate the total cost
    $total = 0;
    foreach ($_SESSION['cart'] as $item) {
        $total += $item['price'] * $item['quantity'];
    }

    // Store receipt data in the session
    $_SESSION['receipt'] = [
        'orderId' => 'ORD-' . rand(100000, 999999),
        'fullName' => $fullName,
        'email' => $email,
        'address' => $address,
        'city' => $city,
        'state' => $state,
        'zip' => $zip,
        'items' => $_SESSION['cart'], // Store cart items
        'tax' => 5.00,  // Example tax
        'total' => $total + 5.00 // Total amount including tax
    ];

    // Clear cart after saving to receipt
    unset($_SESSION['cart']);

    // Redirect to the receipt page
    header('Location: receipt.php');
    exit();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Payment Form</title>
</head>
<body>

<div class="container">

    <form id="paymentForm" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">

        <div class="row">

            <div class="col">

                <h3 class="title">Billing Address</h3>

                <div class="inputBox">
                    <span>Full Name :</span>
                    <input type="text" id="fullName" name="fullName" placeholder="Full Name">
                </div>
                <div class="inputBox">
                    <span>Email :</span>
                    <input type="email" id="email" name="email" placeholder="example@example.com">
                </div>
                <div class="inputBox">
                    <span>Address :</span>
                    <input type="text" id="address" name="address" placeholder="Your Address">
                </div>
                <div class="inputBox">
                    <span>City :</span>
                    <input type="text" id="city" name="city" placeholder="Your City">
                </div>

                <div class="flex">
                    <div class="inputBox">
                        <span>State :</span>
                        <input type="text" id="state" name="state" placeholder="Your state">
                    </div>
                    <div class="inputBox">
                        <span>Zip Code :</span>
                        <input type="text" id="zip" name="zip" placeholder="Zipcode">
                    </div>
                </div>

            </div>

            <div class="col">

                <h3 class="title">Payment</h3>

                <div class="inputBox">
                    <span>Cards Accepted :</span>
                    <img src="img/card_img.png" alt="">
                </div>
                <div class="inputBox">
                    <span>Name On Card :</span>
                    <input type="text" placeholder="Your Card Name">
                </div>
                <div class="inputBox">
                    <span>Credit Card Number :</span>
                    <input type="number" placeholder="1111-2222-3333-4444">
                </div>
                <div class="inputBox">
                    <span>Exp Month :</span>
                    <input type="text" placeholder="Month">
                </div>

                <div class="flex">
                    <div class="inputBox">
                        <span>Exp Year :</span>
                        <input type="number" placeholder="Year">
                    </div>
                    <div class="inputBox">
                        <span>CVV :</span>
                        <input type="text" placeholder="CVV">
                    </div>
                </div>

            </div>
    
        </div>

        <h3>Your Cart:</h3>
    <table width="100%">
        <thead>
            <tr>
                <th>Product</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
        <?php
        $total = 0;
        foreach ($_SESSION['cart'] as $product_id => $item) {
            $subtotal = $item['price'] * $item['quantity'];
            $total += $subtotal;
            ?>
            <tr>
                <td><?php echo $item['name']; ?></td>
                <td>RM<?php echo number_format($item['price'], 2); ?></td>
                <td><?php echo $item['quantity']; ?></td>
                <td>RM<?php echo number_format($subtotal, 2); ?></td>
            </tr>
            <?php
        }

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Get and validate form data
            $fullName = filter_input(INPUT_POST, 'fullName', FILTER_SANITIZE_STRING);
            $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
            $address = filter_input(INPUT_POST, 'address', FILTER_SANITIZE_STRING);
            $city = filter_input(INPUT_POST, 'city', FILTER_SANITIZE_STRING);
            $state = filter_input(INPUT_POST, 'state', FILTER_SANITIZE_STRING);
            $zip = filter_input(INPUT_POST, 'zip', FILTER_SANITIZE_STRING);
        
            // Validate that required fields are not empty
            if (empty($fullName) || empty($email) || empty($address) || empty($city) || empty($state) || empty($zip)) {
                // Handle error - redirect back to the form with an error message
                $_SESSION['error'] = "All fields are required.";
                header('Location: ' . $_SERVER['PHP_SELF']);
                exit();
            }
        
            // Calculate the total cost
            $total = 0;
    foreach ($_SESSION['cart'] as $item) {
        $total += $item['price'] * $item['quantity'];
    }

    // Store receipt data in the session
    $_SESSION['receipt'] = [
        'orderId' => 'ORD-' . rand(100000, 999999),
        'fullName' => $fullName,
        'email' => $email,
        'address' => $address,
        'city' => $city,
        'state' => $state,
        'zip' => $zip,
        'items' => $_SESSION['cart'],
        'tax' => 5.00,  // Example tax
        'total' => $total + 5.00 // Total amount including tax
    ];

    // Clear cart after saving to receipt
    unset($_SESSION['cart']);

    // Redirect to the receipt page
    header('Location: receipt.php');
    exit();
        }
?>
        </tbody>
    </table>
    <h3>Total: RM<?php echo number_format($total, 2); ?></h3>


        <input type="submit" value="Pay Now" class="submit-btn">

    </form>

</div>    
</body>
</html>