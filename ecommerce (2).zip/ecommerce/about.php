<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ecommerce Website</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />
<body>
    
    <section id="header">
        <a href="#"><img src="img/logo.png" class="logo" alt=""></a>

        <div>
            <ul id="navbar">
                <li><a href="index.php">Home</a></li>
                <li><a href="shop.php">Shop</a></li>
                <li><a href="blog.php">Blog</a></li>
                <li><a class="active" href="about.php">About</a></li>
                <li><a href="contact.php">Contact</a></li>
                <li class="lg-bag"><a href="cart.php"><i class="far fa-shopping-bag"></i></a></li>
                <li class="lg-bag"><a href="login.php">Login</i></a></li>
            </ul>
        </div>
        <div id="mobile">
            <a href="cart.php"><i class="far fa-shopping-bag"></i></a>
            <i id="bar" class="fas fa-outdent"></i>
        </div>
    </section>  

    <section id="page-header" class="about-header">
        <h2>About Us</h2>
        <p>Everything That You Need To Know</p>
    </section>

    <section id="about-head" class="section-p1">
        <img src="img/about/a6.jpg" alt="">
        <div>
            <h2>Who we are?</h2>
            <p>Founded by Hidefumi Hommyo in 2000, atmos is known as a prominent Japanese streetwear and sneaker boutique based in Tokyo, Japan. Besides its collaboration with those popular brands including Nike, adidas, Puma, Asics and many more brands, atmos has also come out with its in-house label both in-store and online. atmos currently has more than 30 shops in Japan, as well as international outlets in New York City, Seoul, Bangkok, Jakarta & Kuala Lumpur. atmos always catch the eyes of sneaker lovers with its ability to follow up with the latest sneakers trends. Although atmos now provides a wide range of products, street and sport wears remains the core products in their line. atmos is well known in the fashion industry for its collaboration with major brands including Nike and adidas that are classified as limited or special edition. </p>
            
            <abbr title="">CREATE STUNNING IMAGE</abbr>

            <br><br>

            <marquee bgcolor="#ccc" loop="-1" scrollamount="5" width="100%">Atmos KL</marquee>
        </div>
    </section>

    <section id="about-app" class="section-p1">
        <h1>Download Our <a href="#">App</a></h1>
        <div class="video">
            <video autoplay muted loop src="img/about/1.mp4"></video>
        </div>
    </section>

    <section id="feature" class="section-p1">
        <div class="fe-box">
            <img src="img/features/f1.png" alt="">
            <h6>Free Shipping</h6>
        </div>
        <div class="fe-box">
            <img src="img/features/f2.png" alt="">
            <h6>Online Order</h6>
        </div>
        <div class="fe-box">
            <img src="img/features/f3.png" alt="">
            <h6>12.12 Deal</h6>
        </div>
        <div class="fe-box">
            <img src="img/features/f4.png" alt="">
            <h6>Promotion</h6>
        </div>
        <div class="fe-box">
            <img src="img/features/f5.png" alt="">
            <h6>Happy Hour</h6>
        </div>
        <div class="fe-box">
            <img src="img/features/f6.png" alt="">
            <h6>Support</h6>
        </div>
    </section>

    <section id="newsletter" class="section-p1 section-m1">
        <div class="newstext">
            <h4>Sign Up for Newsletter</h4>
            <p>Get e-Mail updates about our latest drop and <span>special offers</span></p>
        </div>
        <div class="form">
            <input type="text" placeholder="Your e-Mail Address">
            <button class="normal">Notify Me</button>
        </div>
    </section>

    <footer class="section-p1">
        <div class="col">
            <img  class="logo" src="img/logo.png" alt="">
            <h4>Contact</h4>
            <p>Address<strong>14, Gotham Street, 24 South Bridge</strong></p>
            <p>Phone<strong>  (+60)3-3457-6789</strong></p>
            <p>Operation Hours <strong>0800 - 2200, Mon - Sat</strong></p>
            <div class="follow">
                <h4>Follow Us</h4>
                <div class="icon">
                    <i class="fab fa-facebook-f"></i>
                    <i class="fab fa-twitter"></i>
                    <i class="fab fa-instagram"></i>
                    <i class="fab fa-pinterest"></i>
                    <i class="fab fa-youtube"></i>
                </div>
            </div>
        </div>

        <div class="col">
            <h4>About</h4>
            <a href="#">About Us</a>
            <a href="#">Delivery Information</a>
            <a href="#">Privacy & Policy</a>
            <a href="#">Terms & Conditions</a>
            <a href="#">Contact Us</a>
        </div>

        <div class="col">
            <h4>My Account</h4>
            <a href="#">Sign In</a>
            <a href="#">View Cart</a>
            <a href="#">Wishlist</a>
            <a href="#">Track My Order</a>
        </div>

        <div class="col install">
            <h4>Install App</h4>
            <p>App Store or Google Play</p>
            <div class="row">
                <img src="img/pay/app.jpg" alt="">
                <img src="img/pay/play.jpg" alt="">
                <p>Secured Payment Gateways</p>
                <img src="img/pay/pay.png" alt="">
            </div>
        </div>

        <div class="copyright">
            <p>2024, Cara Enterprise</p>
        </div>
    </footer>

    <script src="script.js"></script>
</body>
</html>