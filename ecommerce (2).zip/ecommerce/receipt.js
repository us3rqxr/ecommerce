document.addEventListener('DOMContentLoaded', () => {
    // Retrieve receipt data from localStorage
    const receiptData = JSON.parse(localStorage.getItem('receipt'));

    if (receiptData) {
        // Populate receipt details
        document.getElementById('orderId').textContent = receiptData.orderId;
        document.getElementById('fullName').textContent = receiptData.fullName;
        document.getElementById('email').textContent = receiptData.email;
        document.getElementById('address').textContent = receiptData.address;
        document.getElementById('tax').textContent = receiptData.tax.toFixed(2);
        document.getElementById('total').textContent = receiptData.total.toFixed(2);

        // Populate receipt items
        document.getElementById('receiptItems').innerHTML = receiptData.items
            .map(
                (item) =>
                    `<tr>
                        <td>${item.name}</td>
                        <td>${item.quantity}</td>
                        <td>${item.size}</td>
                        <td>${item.price}</td>
                    </tr>`
            )
            .join('');
    } else {
        document.getElementById('receiptContent').innerHTML = '<p>No order details found.</p>';
    }
});
