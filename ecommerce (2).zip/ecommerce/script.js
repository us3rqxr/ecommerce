const bar = document.getElementById('bar');
const close = document.getElementById('close');
const nav = document.getElementById('navbar');

if (bar) {
    bar.addEventListener('click', () => {
        nav.classList.add('active');
    })
}

if (close) {
    close.addEventListener('click', () => {
        nav.classList.remove('active');
    })
}

document.addEventListener("DOMContentLoaded", function () {
    const addToCartBtn = document.getElementById("add-to-cart");

    addToCartBtn.addEventListener("click", function () {
        // Get product details
        const productName = document.querySelector(".product-details h2").textContent;
        const productPrice = document.querySelector(".product-price").textContent;

        // Get existing cart data from localStorage (if any)
        let cart = JSON.parse(localStorage.getItem("cart")) || [];

        // Create a product object
        const product = {
            name: productName,
            price: productPrice,
            quantity: 1,
        };

        // Check if the product already exists in the cart
        const existingProductIndex = cart.findIndex((item) => item.name === product.name);

        if (existingProductIndex > -1) {
            // If the product exists, increase its quantity
            cart[existingProductIndex].quantity += 1;
        } else {
            // Otherwise, add the product to the cart
            cart.push(product);
        }

        // Save the updated cart to localStorage
        localStorage.setItem("cart", JSON.stringify(cart));

        // Provide feedback to the user
        alert(`${productName} has been added to your cart!`);
    });
});

document.addEventListener("DOMContentLoaded", () => {
    renderCart(); // Call renderCart function on page load
});

function renderCart() {
    console.log("Rendering cart...");

    const cartItemsContainer = document.getElementById("cart-items");
    if (!cartItemsContainer) {
        console.error("Cart items container not found!");
        return;
    }

    cartItemsContainer.innerHTML = ""; // Clear previous items

    let grandTotal = 0;

    cart.forEach((item, index) => {
        // Parse the price (remove '$' sign) and convert to number
        const price = parseFloat(item.price.replace('$', ''));
        
        // Calculate the item total
        const itemTotal = price * item.quantity;
        grandTotal += itemTotal;

        const row = `
            <tr>
                <td><button class="remove-item" data-index="${index}"><i class="far fa-times-circle"></i></button></td>
                <td><img src="${item.image}" alt="${item.name}" width="50"></td>
                <td>${item.name}</td>
                <td>${item.price}</td>
                <td><input type="number" value="${item.quantity}" min="1" data-index="${index}" class="quantity"></td>
                <td>$${itemTotal.toFixed(2)}</td>
            </tr>
        `;
        cartItemsContainer.insertAdjacentHTML("beforeend", row);
    });

    // Update the grand total
    const grandTotalContainer = document.getElementById("grand-total");
    if (grandTotalContainer) {
        grandTotalContainer.textContent = `Total: $${grandTotal.toFixed(2)}`;
    } else {
        console.error("Grand total container not found!");
    }
}

const cart = [
    {
        name: "thisisnevethat (Classic Hoodie)",
        price: "$300.00",
        image: "img/products/f1.jpg",
        quantity: 1
    },
    {
        name: "Carhatt (Crewneck)",
        price: "$500.00",
        image: "img/products/f2.jpg",
        quantity: 2
    }
];

document.getElementById('payment-form').addEventListener("DOMContentLoaded", 'submit', function (e) {
    e.preventDefault();

    const cardName = document.getElementById('card-name').value;
    const cardNumber = document.getElementById('card-number').value;
    const expiryDate = document.getElementById('expiry-date').value;
    const cvv = document.getElementById('cvv').value;
    const billingAddress = document.getElementById('billing-address').value;

    if (!cardName || !cardNumber || !expiryDate || !cvv || !billingAddress) {
        alert('Please fill in all fields.');
        return;
    }

    console.log('Payment Details:', {
        cardName,
        cardNumber,
        expiryDate,
        cvv,
        billingAddress,
    });

    alert('Payment Successful!');
    this.reset();
});

document.addEventListener("DOMContentLoaded", function () {
    const payNowButton = document.getElementById("pay-now");

    if (payNowButton) {
        payNowButton.addEventListener("click", function () {
            // Collect form data
            const name = document.getElementById("name").value;
            const address = document.getElementById("address").value;
            const cardNumber = document.getElementById("card-number").value;
            const expiryDate = document.getElementById("expiry-date").value;
            const cvv = document.getElementById("cvv").value;

            // Validate inputs (optional)
            if (!name || !address || !cardNumber || !expiryDate || !cvv) {
                alert("Please fill out all fields!");
                return;
            }

            // Store data in localStorage
            const receiptData = {
                name,
                address,
                cardNumber: `**** **** **** ${cardNumber.slice(-4)}`, // Mask card number
                expiryDate,
                cvv: "***" // Hide CVV for security
            };

            localStorage.setItem("receiptData", JSON.stringify(receiptData));

            // Redirect to receipt.html
            window.location.href = "receipt.html";
        });
    }
});

document.getElementById("newsletter-form").addEventListener("submit", function (event) {
    event.preventDefault(); // Prevent the default form submission behavior

    const email = document.getElementById("newsletter-email").value;

    if (!email) {
        alert("Please enter a valid email address.");
        return;
    }

    // Example of sending email to backend
    fetch("newsletter.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify({ email: email }),
    })
        .then((response) => response.json())
        .then((data) => {
            if (data.success) {
                alert("Thank you for subscribing to our newsletter!");
                document.getElementById("newsletter-form").reset();
            } else {
                alert("Something went wrong. Please try again later.");
            }
        })
        .catch((error) => {
            console.error("Error:", error);
            alert("There was an error processing your request.");
        });
});

document.addEventListener("DOMContentLoaded", function () {
    const isLoggedIn = localStorage.getItem("isLoggedIn");
    const username = localStorage.getItem("username");

    const loginLink = document.getElementById("login-link"); // The login link in your navbar
    const userGreeting = document.getElementById("user-greeting"); // The user greeting element

    if (isLoggedIn === "true") {
        // User is logged in
        if (loginLink) {
            loginLink.style.display = "none"; // Hide login link
        }

        if (userGreeting) {
            userGreeting.textContent = `Welcome, ${username}!`;
            userGreeting.style.display = "block"; // Show user greeting
        }
    } else {
        // User is not logged in
        if (userGreeting) {
            userGreeting.style.display = "none"; // Hide user greeting
        }
    }
});

document.addEventListener("DOMContentLoaded", function () {
    const logoutLink = document.getElementById("logout-link");

    if (logoutLink) {
        logoutLink.addEventListener("click", function () {
            // Clear login state
            localStorage.removeItem("isLoggedIn");
            localStorage.removeItem("username");

            // Redirect to login page
            window.location.href = "login.html";
        });
    }
});

/*=============== SHOW HIDE PASSWORD LOGIN ===============*/
const passwordAccess = (loginPass, loginEye) =>{
    const input = document.getElementById(loginPass),
          iconEye = document.getElementById(loginEye)
 
    iconEye.addEventListener('click', () =>{
       // Change password to text
       input.type === 'password' ? input.type = 'text'
                                       : input.type = 'password'
 
       // Icon change
       iconEye.classList.toggle('ri-eye-fill')
       iconEye.classList.toggle('ri-eye-off-fill')
    })
 }
 passwordAccess('password','loginPassword')
 
 /*=============== SHOW HIDE PASSWORD CREATE ACCOUNT ===============*/
 const passwordRegister = (loginPass, loginEye) =>{
    const input = document.getElementById(loginPass),
          iconEye = document.getElementById(loginEye)
 
    iconEye.addEventListener('click', () =>{
       // Change password to text
       input.type === 'password' ? input.type = 'text'
                                       : input.type = 'password'
 
       // Icon change
       iconEye.classList.toggle('ri-eye-fill')
       iconEye.classList.toggle('ri-eye-off-fill')
    })
 }
 passwordRegister('passwordCreate','loginPasswordCreate')
 
 /*=============== SHOW HIDE LOGIN & CREATE ACCOUNT ===============*/
 const loginAcessRegister = document.getElementById('loginAccessRegister'),
       buttonRegister = document.getElementById('loginButtonRegister'),
       buttonAccess = document.getElementById('loginButtonAccess')
 
 buttonRegister.addEventListener('click', () => {
    loginAcessRegister.classList.add('active')
 })
 
 buttonAccess.addEventListener('click', () => {
    loginAcessRegister.classList.remove('active')
 })
 
